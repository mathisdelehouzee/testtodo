export default class ToDo {
  constructor (id, title, completed) {
    this.id = id
    this.title = title
    this.completed = completed
  }
}
